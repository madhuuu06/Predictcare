"""
PredictCare – Flask app: appointment booking + ML urgency & waiting time prediction.
"""

import os
import sqlite3
import joblib
from flask import Flask, render_template, request, redirect, url_for, jsonify

# ===== EMAIL IMPORTS =====
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)

_BASE = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(_BASE, "models")
DB_PATH = os.path.join(_BASE, "predictcare.db")

# ================= EMAIL CONFIGURATION =================
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

SENDER_EMAIL = "madhukadajji06@gmail.com"
SENDER_PASSWORD = "iwlgygalrzociaxu"

# ================= HOSPITAL EMAILS =================
HOSPITAL_EMAILS = {
    "Apollo Hospital": "apollohospital.notify@gmail.com",
    "Fortis Hospital": "fortishospital.notify@gmail.com",
    "Manipal Hospital": "manipalhospital.notify@gmail.com"
}

# ================= DOCTOR EMAILS =================
DOCTOR_EMAILS = {
    "Dr. Anil Kumar": "dr.anilkumar.notify@gmail.com",
    "Dr. Priya Sharma": "dr.priyasharma.notify@gmail.com",
    "Dr. Rohit Verma": "dr.rohitverma.notify@gmail.com",
    "Dr. Sneha Reddy": "dr.snehareddy.notify@gmail.com",
    "Dr. Arjun Rao": "dr.arjunrao.notify@gmail.com",
    "Dr. Meena Iyer": "dr.meenaiyer.notify@gmail.com",
    "Dr. Kavya Nair": "dr.kavyanair.notify@gmail.com",
    "Dr. Rahul Jain": "dr.rahuljain.notify@gmail.com",
    "Dr. Pooja Menon": "dr.poojamenon.notify@gmail.com",
    "Dr. Kiran Patel": "dr.kiranpatel.notify@gmail.com",
    "Dr. Neha Joshi": "dr.nehajoshi.notify@gmail.com",
    "Dr. Sandeep Kulkarni": "dr.sandeepkulkarni.notify@gmail.com",
    "Dr. Vivek Shetty": "dr.vivekshetty.notify@gmail.com",
    "Dr. Aishwarya Rao": "dr.aishwaryarao.notify@gmail.com",
    "Dr. Harish Babu": "dr.harishbabu.notify@gmail.com",
    "Dr. Divya Krishnan": "dr.divyakrishnan.notify@gmail.com",

    "Dr. Karthik Rao": "dr.karthikrao.notify@gmail.com",
    "Dr. Deepa Menon": "dr.deepamenon.notify@gmail.com",
    "Dr. Ajay Mehta": "dr.ajaymehta.notify@gmail.com",
    "Dr. Poonam Shah": "dr.poonamshah.notify@gmail.com",
    "Dr. Vinay Kulkarni": "dr.vinaykulkarni.notify@gmail.com",
    "Dr. Ritu Desai": "dr.ritudesai.notify@gmail.com",
    "Dr. Sanjana Nair": "dr.sanjananair.notify@gmail.com",
    "Dr. Mohit Sinha": "dr.mohitsinha.notify@gmail.com",
    "Dr. Lakshmi Prasad": "dr.lakshmiprasad.notify@gmail.com",
    "Dr. Vivek Nair": "dr.viveknair.notify@gmail.com",
    "Dr. Anusha Reddy": "dr.anushareddy.notify@gmail.com",
    "Dr. Prakash Shetty": "dr.prakashshetty.notify@gmail.com",
    "Dr. Nikhil Joshi": "dr.nikhiljoshi.notify@gmail.com",
    "Dr. Shreya Iyer": "dr.shreyaiyer.notify@gmail.com",
    "Dr. Harsha Rao": "dr.harsharao.notify@gmail.com",
    "Dr. Kavita Bhat": "dr.kavitabhat.notify@gmail.com",

    "Dr. Rajesh Kumar": "dr.rajeshkumar.notify@gmail.com",
    "Dr. Nandini Rao": "dr.nandinirao.notify@gmail.com",
    "Dr. Suraj Patel": "dr.surajpatel.notify@gmail.com",
    "Dr. Megha Varma": "dr.meghavarma.notify@gmail.com",
    "Dr. Tarun Babu": "dr.tarunbabu.notify@gmail.com",
    "Dr. Keerthi Jain": "dr.keerthijain.notify@gmail.com",
    "Dr. Rohan Menon": "dr.rohanmenon.notify@gmail.com",
    "Dr. Aditi Kapoor": "dr.aditikapoor.notify@gmail.com",
    "Dr. Suresh Naik": "dr.sureshnaik.notify@gmail.com",
    "Dr. Bhavana Reddy": "dr.bhavanareddy.notify@gmail.com",
    "Dr. Neeraj Patil": "dr.neerajpatil.notify@gmail.com",
    "Dr. Divya S": "dr.divyas.notify@gmail.com",
    "Dr. Akash Hegde": "dr.akashhegde.notify@gmail.com",
    "Dr. Priti Kulkarni": "dr.pritikulkarni.notify@gmail.com",
    "Dr. Siddharth Rao": "dr.siddharthrao.notify@gmail.com",
    "Dr. Asha Menon": "dr.ashamenon.notify@gmail.com"
}

# ================= FIXED TIME SLOTS =================
ALL_TIME_SLOTS = [
    "09:00", "09:30", "10:00", "10:30",
    "11:00", "11:30", "12:00", "12:30",
    "14:00", "14:30", "15:00", "15:30",
    "16:00", "16:30"
]


def send_email(to_email, subject, body):
    try:
        msg = MIMEMultipart()
        msg["From"] = SENDER_EMAIL
        msg["To"] = to_email
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.send_message(msg)
        server.quit()

        print(f"Email sent successfully to {to_email}")
        return True

    except Exception as e:
        print(f"Email sending failed to {to_email}: {e}")
        return False


def send_confirmation_email(to_email, patient_name, hospital, department, doctor, date, time, urgency):
    subject = "PredictCare Appointment Confirmation"

    body = f"""
Hello {patient_name},

Your appointment has been successfully booked.

Appointment Details:
----------------------
Hospital            : {hospital}
Department          : {department}
Doctor              : {doctor}
Date                : {date}
Time                : {time}
Predicted Urgency   : {urgency}

Please arrive 10 minutes early.

Thank you,
PredictCare Team
"""
    return send_email(to_email, subject, body)


def send_hospital_notification(hospital_email, hospital, patient_name, department, doctor, urgency, priority_rank, date, time):
    subject = f"PredictCare Alert – {urgency} Priority Appointment"

    body = f"""
Hospital Notification

A new appointment has been booked through PredictCare.

Patient Name        : {patient_name}
Hospital            : {hospital}
Department          : {department}
Doctor              : {doctor}
Urgency Level       : {urgency}
Priority Rank       : {priority_rank}
Appointment Date    : {date}
Appointment Time    : {time}

Please prioritize this case accordingly.

Regards,
PredictCare System
"""
    return send_email(hospital_email, subject, body)


def send_doctor_notification(doctor_email, patient_name, hospital, department, doctor, urgency, priority_rank, date, time):
    subject = f"PredictCare Doctor Alert – {urgency} Priority Patient"

    body = f"""
Doctor Notification

A patient appointment has been assigned to you.

Patient Name        : {patient_name}
Hospital            : {hospital}
Department          : {department}
Doctor              : {doctor}
Urgency Level       : {urgency}
Priority Rank       : {priority_rank}
Appointment Date    : {date}
Appointment Time    : {time}

Please be prepared accordingly.

Regards,
PredictCare System
"""
    return send_email(doctor_email, subject, body)


def load_models():
    try:
        enc = joblib.load(os.path.join(MODELS_DIR, "symptom_encoder.pkl"))
        urgency_clf = joblib.load(os.path.join(MODELS_DIR, "urgency_model.pkl"))
        urgency_enc = joblib.load(os.path.join(MODELS_DIR, "urgency_encoder.pkl"))
        wait_reg = joblib.load(os.path.join(MODELS_DIR, "waiting_time_model.pkl"))
        return enc, urgency_clf, urgency_enc, wait_reg
    except FileNotFoundError as e:
        raise FileNotFoundError(
            "ML models not found. Run from project root: python generate_data.py then python train_models.py"
        ) from e


encoders, urgency_model, urgency_encoder, waiting_time_model = load_models()


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_name TEXT NOT NULL,
            email TEXT NOT NULL,
            age INTEGER NOT NULL,
            symptom TEXT NOT NULL,
            hospital TEXT NOT NULL,
            department TEXT NOT NULL,
            doctor TEXT NOT NULL,
            appointment_date TEXT NOT NULL,
            appointment_time TEXT NOT NULL,
            urgency TEXT NOT NULL,
            priority_rank INTEGER NOT NULL,
            urgency_score INTEGER NOT NULL,
            waiting_time_minutes INTEGER NOT NULL,
            recommended_department TEXT,
            explanation TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


SYMPTOM_RECOMMENDATION = {
    "Fever": "General Medicine",
    "Cough": "General Medicine",
    "Headache": "Neurology",
    "Chest pain": "Cardiology",
    "Abdominal pain": "Gastroenterology",
    "Rash": "Dermatology",
    "Fatigue": "General Medicine",
    "Sore throat": "ENT",
    "Back pain": "Orthopedics",
    "Joint pain": "Orthopedics",
    "Shortness of breath": "Cardiology",
    "Dizziness": "Neurology",
    "Nausea": "Gastroenterology",
    "Eye problem": "General Medicine",
    "Ear pain": "ENT",
}


def get_priority_rank(urgency_label):
    if urgency_label == "High":
        return 1
    elif urgency_label == "Medium":
        return 2
    return 3


def predict_urgency_and_wait(age, symptom, department):
    symptom_enc = encoders["symptom"]
    dept_enc = encoders["department"]

    try:
        s_code = symptom_enc.transform([symptom])[0]
    except Exception:
        s_code = 0

    try:
        d_code = dept_enc.transform([department])[0]
    except Exception:
        d_code = 0

    X = [[age, s_code, d_code]]

    urgency_idx = urgency_model.predict(X)[0]
    urgency_label = urgency_encoder.inverse_transform([urgency_idx])[0]

    wait_min = max(5, min(120, int(waiting_time_model.predict(X)[0])))

    recommended = SYMPTOM_RECOMMENDATION.get(symptom, department)

    score_map = {"Low": 25, "Medium": 55, "High": 88}
    base_score = score_map.get(urgency_label, 50)
    urgency_score = max(0, min(100, base_score + (wait_min % 10) - 5))

    explanation = (
        f"Based on your symptom ({symptom}), age ({age}), and selected department ({department}), "
        f"the system predicts {urgency_label} urgency. "
        f"Recommended department: {recommended}. "
        f"Estimated waiting time: about {wait_min} minutes."
    )

    return urgency_label, urgency_score, wait_min, recommended, explanation


@app.route("/")
def index():
    slot_error = request.args.get("slot_error", "")
    return render_template("index.html", slot_error=slot_error)


# ================= AVAILABLE SLOTS ROUTE =================
@app.route("/get_available_slots")
def get_available_slots():
    hospital = request.args.get("hospital", "").strip()
    doctor = request.args.get("doctor", "").strip()
    appointment_date = request.args.get("appointment_date", "").strip()

    if not hospital or not doctor or not appointment_date:
        return jsonify([])

    conn = get_db()
    booked_rows = conn.execute("""
        SELECT appointment_time FROM appointments
        WHERE hospital = ? AND doctor = ? AND appointment_date = ?
    """, (hospital, doctor, appointment_date)).fetchall()
    conn.close()

    booked_slots = [row["appointment_time"] for row in booked_rows]
    available_slots = [slot for slot in ALL_TIME_SLOTS if slot not in booked_slots]

    return jsonify(available_slots)


@app.route("/book", methods=["POST"])
def book():
    name = request.form.get("patient_name", "").strip()
    email = request.form.get("email", "").strip()
    age = request.form.get("age", type=int)
    symptom = request.form.get("symptom", "").strip()
    hospital = request.form.get("hospital", "").strip()
    department = request.form.get("department", "").strip()
    doctor = request.form.get("doctor", "").strip()
    appt_date = request.form.get("appointment_date", "").strip()
    appt_time = request.form.get("appointment_time", "").strip()

    if not name or not email or age is None or not symptom or not hospital or not department or not doctor or not appt_date or not appt_time:
        return redirect(url_for("index"))

    if age < 1 or age > 120:
        age = 30

    conn = get_db()
    existing_slot = conn.execute("""
        SELECT * FROM appointments
        WHERE hospital = ?
        AND doctor = ?
        AND appointment_date = ?
        AND appointment_time = ?
    """, (hospital, doctor, appt_date, appt_time)).fetchone()

    if existing_slot:
        conn.close()
        return redirect(url_for(
            "index",
            slot_error="This doctor is already booked for the selected date and time. Please choose another doctor or time slot."
        ))

    urgency_label, urgency_score, wait_min, recommended, explanation = predict_urgency_and_wait(
        age, symptom, department
    )

    priority_rank = get_priority_rank(urgency_label)

    cur = conn.execute(
        """INSERT INTO appointments (
            patient_name, email, age, symptom, hospital, department, doctor, appointment_date, appointment_time,
            urgency, priority_rank, urgency_score, waiting_time_minutes, recommended_department, explanation
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            name, email, age, symptom, hospital, department, doctor, appt_date, appt_time,
            urgency_label, priority_rank, urgency_score, wait_min, recommended, explanation
        ),
    )
    appt_id = cur.lastrowid
    conn.commit()
    conn.close()

    patient_notified = send_confirmation_email(
        to_email=email,
        patient_name=name,
        hospital=hospital,
        department=department,
        doctor=doctor,
        date=appt_date,
        time=appt_time,
        urgency=urgency_label
    )

    hospital_notified = False
    doctor_notified = False

    hospital_email = HOSPITAL_EMAILS.get(hospital)
    if hospital_email:
        hospital_notified = send_hospital_notification(
            hospital_email=hospital_email,
            hospital=hospital,
            patient_name=name,
            department=department,
            doctor=doctor,
            urgency=urgency_label,
            priority_rank=priority_rank,
            date=appt_date,
            time=appt_time
        )

    doctor_email = DOCTOR_EMAILS.get(doctor)
    if doctor_email:
        doctor_notified = send_doctor_notification(
            doctor_email=doctor_email,
            patient_name=name,
            hospital=hospital,
            department=department,
            doctor=doctor,
            urgency=urgency_label,
            priority_rank=priority_rank,
            date=appt_date,
            time=appt_time
        )

    return redirect(url_for(
        "results",
        id=appt_id,
        patient_notified=str(patient_notified),
        doctor_notified=str(doctor_notified),
        hospital_notified=str(hospital_notified)
    ))


@app.route("/results")
def results():
    appt_id = request.args.get("id", type=int)
    if not appt_id:
        return redirect(url_for("index"))

    conn = get_db()
    row = conn.execute(
        "SELECT * FROM appointments WHERE id = ?", (appt_id,)
    ).fetchone()
    conn.close()

    if not row:
        return redirect(url_for("index"))

    r = dict(row)
    return render_template(
        "results.html",
        urgency=r.get("urgency", "Medium"),
        urgency_score=int(r.get("urgency_score", 50)),
        waiting_minutes=int(r.get("waiting_time_minutes", 30)),
        recommended_department=r.get("recommended_department", ""),
        explanation=r.get("explanation", ""),
        patient_name=r.get("patient_name", ""),
        appointment_date=r.get("appointment_date", ""),
        appointment_time=r.get("appointment_time", ""),
        hospital=r.get("hospital", ""),
        department=r.get("department", ""),
        doctor=r.get("doctor", ""),
        priority_rank=r.get("priority_rank", 3),
        patient_notified=request.args.get("patient_notified", "False"),
        doctor_notified=request.args.get("doctor_notified", "False"),
        hospital_notified=request.args.get("hospital_notified", "False")
    )


@app.route("/admin")
def admin():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM appointments ORDER BY priority_rank ASC, created_at DESC LIMIT 100"
    ).fetchall()
    conn.close()
    appointments = [dict(r) for r in rows]
    return render_template("admin.html", appointments=appointments)


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)