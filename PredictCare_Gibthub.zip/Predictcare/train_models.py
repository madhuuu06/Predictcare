"""
Train simple ML models for PredictCare: urgency (classification) and waiting time (regression).
Requires data/healthcare_data.csv from generate_data.py.
Saves models to models/ using joblib.
"""
import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor

_BASE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(_BASE, "data", "healthcare_data.csv")
MODELS_DIR = os.path.join(_BASE, "models")

def main():
    os.makedirs(MODELS_DIR, exist_ok=True)
    df = pd.read_csv(DATA_PATH)

    # Encode categorical features
    symptom_enc = LabelEncoder()
    dept_enc = LabelEncoder()
    df["symptom_encoded"] = symptom_enc.fit_transform(df["symptom"].astype(str))
    df["department_encoded"] = dept_enc.fit_transform(df["department"].astype(str))

    # Urgency: classification
    urgency_enc = LabelEncoder()
    y_urgency = urgency_enc.fit_transform(df["urgency"])
    X = df[["age", "symptom_encoded", "department_encoded"]]
    X_train, X_test, y_train, y_test = train_test_split(X, y_urgency, test_size=0.2, random_state=42)
    clf = RandomForestClassifier(n_estimators=50, max_depth=8, random_state=42)
    clf.fit(X_train, y_train)
    acc = (clf.predict(X_test) == y_test).mean()
    print(f"Urgency model accuracy: {acc:.2%}")

    joblib.dump(clf, os.path.join(MODELS_DIR, "urgency_model.pkl"))
    joblib.dump(urgency_enc, os.path.join(MODELS_DIR, "urgency_encoder.pkl"))

    # Waiting time: regression
    y_wait = df["waiting_time_minutes"]
    X_train2, X_test2, y_train2, y_test2 = train_test_split(X, y_wait, test_size=0.2, random_state=42)
    reg = RandomForestRegressor(n_estimators=50, max_depth=8, random_state=42)
    reg.fit(X_train2, y_train2)
    from sklearn.metrics import mean_absolute_error
    mae = mean_absolute_error(y_test2, reg.predict(X_test2))
    print(f"Waiting time MAE: {mae:.1f} minutes")

    joblib.dump(reg, os.path.join(MODELS_DIR, "waiting_time_model.pkl"))

    # Save encoders for app (symptom + department for encoding user input)
    encoders = {"symptom": symptom_enc, "department": dept_enc}
    joblib.dump(encoders, os.path.join(MODELS_DIR, "symptom_encoder.pkl"))

    print("Models saved to", MODELS_DIR)

if __name__ == "__main__":
    main()
