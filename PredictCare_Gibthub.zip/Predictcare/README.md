# PredictCare

A simple ML-based appointment booking and urgency prediction system (mini/course project).

**Stack:** Flask, HTML/CSS/Bootstrap, scikit-learn, SQLite.

## Features

- **Booking:** Patient name, age, symptom, department, date & time.
- **ML prediction:** Urgency (Low / Medium / High), urgency score (0–100), waiting time (minutes), department recommendation, short explanation.
- **UI:** Bootstrap; urgency shown in green (low), orange (medium), red (high).
- **Admin:** View recent appointments (no login).

## Setup (Windows)

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python generate_data.py
python train_models.py
python app.py
```

Then open: **http://127.0.0.1:5000**

## Project structure

```
PredictCare/
├── app.py              # Flask app + SQLite + ML inference
├── requirements.txt
├── data/
│   └── healthcare_data.csv   # Created by generate_data.py
├── models/
│   ├── urgency_model.pkl     # Created by train_models.py
│   ├── urgency_encoder.pkl
│   ├── waiting_time_model.pkl
│   └── symptom_encoder.pkl
├── templates/
│   ├── index.html      # Booking form
│   ├── results.html    # Result + urgency
│   └── admin.html      # List appointments
├── static/
│   └── style.css
├── generate_data.py    # Synthetic CSV
├── train_models.py     # Train & save models
└── README.md
```

## ML details

- **Classification:** Random Forest for urgency (Low/Medium/High).
- **Regression:** Random Forest for waiting time (minutes).
- **Data:** Synthetic CSV; encoders and models saved with joblib.

No authentication or advanced analytics; suitable for a small course/mini project.
