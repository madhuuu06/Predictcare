"""
Generate synthetic healthcare data for PredictCare ML models.
Run once to create data/healthcare_data.csv.
"""
import os
import random
import pandas as pd

# Create data directory next to this script
_DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(_DATA_DIR, exist_ok=True)

# Simple synthetic data for urgency (classification) and waiting_time (regression)
SYMPTOMS = [
    "Fever", "Cough", "Headache", "Chest pain", "Abdominal pain",
    "Rash", "Fatigue", "Sore throat", "Back pain", "Joint pain",
    "Shortness of breath", "Dizziness", "Nausea", "Eye problem", "Ear pain"
]

DEPARTMENTS = [
    "General Medicine", "Cardiology", "Orthopedics", "Dermatology",
    "ENT", "Pediatrics", "Neurology", "Gastroenterology"
]

# Map symptom -> typical department (for recommendation)
SYMPTOM_TO_DEPT = {
    "Fever": "General Medicine",
    "Cough": "General Medicine",
    "Headache": "Neurology",
    "Chest pain": "Cardiology",
    "Abdominal pain": "Gastroenterology",
    "Rash": "Dermatology",
    "Fatigue": "General Medicine",
    "Sore throat": "ENT",
    "Back pain": "Orthopedics",
    "Joint pain": "Orthopedics",
    "Shortness of breath": "Cardiology",
    "Dizziness": "Neurology",
    "Nausea": "Gastroenterology",
    "Eye problem": "General Medicine",
    "Ear pain": "ENT",
}

# Urgency: some symptoms tend to be higher urgency
HIGH_URGENCY = {"Chest pain", "Shortness of breath", "Abdominal pain"}
MEDIUM_URGENCY = {"Fever", "Dizziness", "Headache", "Nausea", "Eye problem"}

def urgency_for_row(symptom, age):
    """Simple rule-based urgency for synthetic labels."""
    base = "Low"
    if symptom in HIGH_URGENCY:
        base = "High"
    elif symptom in MEDIUM_URGENCY or age > 65:
        base = "Medium"
    # Add some randomness
    r = random.random()
    if base == "High" and r < 0.1:
        base = "Medium"
    elif base == "Low" and r < 0.15:
        base = "Medium"
    elif base == "Medium" and r < 0.2:
        base = "High" if r < 0.1 else "Low"
    return base

def waiting_time_minutes(urgency):
    """Synthetic waiting time by urgency (minutes)."""
    if urgency == "High":
        return random.randint(5, 25)
    if urgency == "Medium":
        return random.randint(20, 55)
    return random.randint(40, 90)

def main():
    n = 800
    rows = []
    for _ in range(n):
        age = random.randint(5, 85)
        symptom = random.choice(SYMPTOMS)
        department = SYMPTOM_TO_DEPT.get(symptom, random.choice(DEPARTMENTS))
        urgency = urgency_for_row(symptom, age)
        wait = waiting_time_minutes(urgency)
        rows.append({
            "age": age,
            "symptom": symptom,
            "department": department,
            "urgency": urgency,
            "waiting_time_minutes": wait,
        })
    df = pd.DataFrame(rows)
    path = os.path.join(_DATA_DIR, "healthcare_data.csv")
    df.to_csv(path, index=False)
    print(f"Generated {len(df)} rows -> {path}")

if __name__ == "__main__":
    main()
